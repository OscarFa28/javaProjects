package gridcalcu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
/**
 *
 * @author of_de
 */
public class grafic extends JFrame{
    
    private JTextField pantalla;
    private JButton cero,uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,del,res,sum,rest,div,multi;
    
    ArrayList<String> Valor = new ArrayList<String>();
    String oper="";
    int n=0;
    double resu;
    boolean util = false,util2 =false;
    
    
    
    public grafic (){
        
        
        JPanel panel = new JPanel(new GridBagLayout());
        
        pantalla  = new JTextField();
        cero = new JButton("0");
        uno = new JButton("1");
        dos = new JButton("2");
        tres = new JButton("3");
        cuatro = new JButton("4");
        cinco = new JButton("5");
        seis = new JButton("6");
        siete = new JButton("7");
        ocho = new JButton("8");
        nueve = new JButton("9");
        del = new JButton("C");
        res = new JButton("=");
        sum = new JButton("+");
        rest = new JButton("-");
        div = new JButton("/");
        multi = new JButton("x");
        
        GridBagConstraints gridB = new GridBagConstraints();
        
        
        Insets insets = new Insets(2, 2, 2, 2);
        gridB.insets = insets; //separación
        gridB.weighty = 1; //alto
        gridB.weightx= 1; //ancho
        
            
        
        gridB.gridx = 2; //columna
            gridB.gridy = 5; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(del, gridB);
        
            gridB.gridx = 0; //columna
            gridB.gridy = 5; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 2;//ancho
            gridB.gridheight = 1;//altura
        panel.add(cero, gridB);
        
            gridB.gridx = 0; //columna
            gridB.gridy = 4; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(uno, gridB);
        
            gridB.gridx = 1; //columna
            gridB.gridy = 4; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(dos, gridB);
        
            gridB.gridx = 2; //columna
            gridB.gridy = 4; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(tres, gridB);        
   
            gridB.gridx = 0; //columna
            gridB.gridy = 2; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(cuatro, gridB);

            gridB.gridx = 1; //columna
            gridB.gridy = 2; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(cinco, gridB);
        
            gridB.gridx = 2; //columna
            gridB.gridy = 2; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(seis, gridB);
        
            gridB.gridx = 0; //columna
            gridB.gridy = 1; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(siete, gridB);
        
            gridB.gridx = 1; //columna
            gridB.gridy = 1; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(ocho, gridB);
        
            gridB.gridx = 2; //columna
            gridB.gridy = 1; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
        panel.add(nueve, gridB);
        
        //Acciones
            gridB.gridx = 0; //columna
            gridB.gridy = 6; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 4;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 2, 2, 2);
        panel.add(res, gridB);
        
            gridB.gridx = 3; //columna
            gridB.gridy = 5; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 7, 2, 2);
        panel.add(rest, gridB);
        
            gridB.gridx = 3; //columna
            gridB.gridy = 4; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 7, 2, 2);
        panel.add(sum, gridB);
        
            gridB.gridx = 3; //columna
            gridB.gridy = 4; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 7, 2, 2);
        panel.add(sum, gridB);
        
            gridB.gridx = 3; //columna
            gridB.gridy = 2; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 7, 2, 2);
        panel.add(div, gridB);
        
            gridB.gridx = 3; //columna
            gridB.gridy = 1; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 1;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 7, 2, 2);
        panel.add(multi, gridB);
        
            gridB.gridx = 0; //columna
            gridB.gridy = 0; //fila
            gridB.fill = GridBagConstraints.BOTH;
            gridB.gridwidth = 4;//ancho
            gridB.gridheight = 1;//altura
            gridB.insets = new Insets(2, 2, 7, 2);
        panel.add(pantalla, gridB);
        
        add(panel);
        JButton[] botones = new JButton[] {cero, uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve};
        //COLORES
        getContentPane().setBackground(Color.decode("#252525"));
        
        panel.setBackground(Color.decode("#252525")); // Fondo transparente
        
        
        pantalla.setBackground(Color.decode("#595959"));
        pantalla.setOpaque(true);
        pantalla.setBorder(BorderFactory.createLineBorder(Color.decode("#595959")));
        pantalla.setForeground(Color.WHITE);
        pantalla.setFont(new Font(pantalla.getFont().getName(), Font.PLAIN, 50));
        pantalla.setHorizontalAlignment(JTextField.CENTER);
        
        
        
        sum.setBackground(Color.decode("#FFAB03"));
        sum.setOpaque(true);
        sum.setBorder(BorderFactory.createLineBorder(Color.decode("#FFAB03")));
        sum.setForeground(Color.WHITE);
        sum.setFont(new Font(sum.getFont().getName(), Font.PLAIN, 50));
        
        rest.setBackground(Color.decode("#FFAB03"));
        rest.setOpaque(true);
        rest.setBorder(BorderFactory.createLineBorder(Color.decode("#FFAB03")));
        rest.setForeground(Color.WHITE);
        rest.setFont(new Font(rest.getFont().getName(), Font.PLAIN, 50));
        
        div.setBackground(Color.decode("#FFAB03"));
        div.setOpaque(true);
        div.setBorder(BorderFactory.createLineBorder(Color.decode("#FFAB03")));
        div.setForeground(Color.WHITE);
        div.setFont(new Font(div.getFont().getName(), Font.PLAIN, 50));
        
        multi.setBackground(Color.decode("#FFAB03"));
        multi.setOpaque(true);
        multi.setBorder(BorderFactory.createLineBorder(Color.decode("#FFAB03")));
        multi.setForeground(Color.WHITE);
        multi.setFont(new Font(multi.getFont().getName(), Font.PLAIN, 50));
        
        res.setBackground(Color.decode("#141414"));
        res.setOpaque(true);
        res.setBorder(BorderFactory.createLineBorder(Color.decode("#141414")));
        res.setForeground(Color.WHITE);
        res.setFont(new Font(res.getFont().getName(), Font.PLAIN, 50));
        
        del.setBackground(Color.decode("#E53939"));
        del.setOpaque(true);
        del.setBorder(BorderFactory.createLineBorder(Color.decode("#E53939")));
        del.setForeground(Color.WHITE);
        del.setFont(new Font(del.getFont().getName(), Font.PLAIN, 50));
        
        for (JButton boton : botones) {
    boton.setBackground(Color.decode("#141414"));
    boton.setOpaque(true);
    boton.setBorder(BorderFactory.createLineBorder(Color.decode("#141414")));
    boton.setForeground(Color.WHITE);
    boton.setFont(new Font(boton.getFont().getName(), Font.PLAIN, 50));
}
        
        //BOTONES
        sum.addActionListener(new Sumar());
        rest.addActionListener(new Restar());
        multi.addActionListener(new Multiplicar());
        div.addActionListener(new Dividir());
        res.addActionListener(new Resultado());
        del.addActionListener(new Borrar());
        
        cero.addActionListener(new nCero());
        uno.addActionListener(new nUno());
        dos.addActionListener(new nDos());
        tres.addActionListener(new nTres());
        cuatro.addActionListener(new nCuatro());
        cinco.addActionListener(new nCinco());
        seis.addActionListener(new nSeis());
        siete.addActionListener(new nSiete());
        ocho.addActionListener(new nOcho());
        nueve.addActionListener(new nNueve());
        
         setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    }
    
    public class Sumar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (util==false){
            Valor.add(pantalla.getText());
            oper=oper+Valor.get(n)+"+";
            n++;
            pantalla.setText("");
        }else{
                oper=oper+Valor.get(n)+"+";
                pantalla.setText("");
                util=false;
                n++;
                util2=false;
            }
        }
        
    }
    public class Restar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (util==false){
            Valor.add(pantalla.getText());
            oper=oper+Valor.get(n)+"-";
            n++;
            pantalla.setText("");
        }else{
                oper=oper+Valor.get(n)+"-";
                pantalla.setText("");
                util=false;
                n++;
                util2=false;
            }
        }
        
    }
    public class Multiplicar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (util==false){
            Valor.add(pantalla.getText());
            oper=oper+Valor.get(n)+"*";
            n++;
            pantalla.setText("");
        }else{
                oper=oper+Valor.get(n)+"*";
                pantalla.setText("");
                util=false;
                n++;
                util2=false;

            }
        }
        
    }
    public class Dividir implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (util==false){
            Valor.add(pantalla.getText());
            oper=oper+Valor.get(n)+"/";
            n++;
            pantalla.setText("");
        }else{
                oper=oper+Valor.get(n)+"/";
                pantalla.setText("");
                util=false;
                n++;
                util2=false;

            }
        }
        
    }
    public class Resultado implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            oper=oper+pantalla.getText();
          ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        try {
            Object result = engine.eval(oper);
            resu = Double.parseDouble(result.toString());
            System.out.println(resu);
        } catch (ScriptException e) {
            e.printStackTrace();
        
    }
        n=0;
        pantalla.setText(resu+"");
        Valor.clear();
        util2=true;
        Valor.add(resu+"");
        oper="";
        util=true;
        }
        
    }
    public class Borrar implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            if(!"".equals(pantalla.getText())){
            String dígito = pantalla.getText();
            //dígito = dígito.substring(0, dígito.length() - 1);
            pantalla.setText("");
            //pantalla.setText(dígito);
            }
        }
        
    }
    public class nCero implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(0);
    }
        
}

public class nUno implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(1);
    }
        
}

public class nDos implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(2);
    }
        
}

// Clase para el botón 3
public class nTres implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
       numeros(3);
    }
        
}

// Clase para el botón 4
public class nCuatro implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(4);
    }
        
}

// Clase para el botón 5
public class nCinco implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(5);
    }
        
}

// Clase para el botón 6
public class nSeis implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(6);
    }
        
}

// Clase para el botón 7
public class nSiete implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(7);
    }
        
}

// Clase para el botón 8
public class nOcho implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(8);
    }
        
}

// Clase para el botón 9
public class nNueve implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent ae) {
        numeros(9);
    }
        
}
    
    void numeros (int x){
        if (util==true){
            pantalla.setText("");
        }
        if(util2==true){
            Valor.clear();
            oper="";
            util =false;
            util2=false;
        }
        
        String pt = pantalla.getText();
        pantalla.setText(pt+x);
    }
}
