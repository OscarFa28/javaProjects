/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gridcalcu;

/**
 *
 * @author of_de
 */
public class GridCalcu {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        grafic calc = new grafic();
        
        calc.setSize(500,700);
        calc.setVisible(true);
    }
    
}
